print('b')
print(chr(98)) # 也输出了b， 使用 chr（将98转换成对ASCII码所对应的字符）
print('c')
print(chr(67))
print(8)
print(chr(56))
print('[')
print(chr(91))
 # 中文编码的范围[u4e00~u9fa5]
