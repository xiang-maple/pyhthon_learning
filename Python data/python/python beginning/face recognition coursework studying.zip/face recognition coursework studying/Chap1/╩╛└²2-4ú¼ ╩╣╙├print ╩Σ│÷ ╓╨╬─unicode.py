print('bei')
print('jing')
print(chr(21271+20140))
print(ord('蒋'))
