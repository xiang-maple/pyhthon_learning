fp=open('heihei.txt','w')
print('北京',end='\嘻嘻')
print('欢迎你') # 没有去修改结束符，所以再print之后会有一个空行
print('niub')