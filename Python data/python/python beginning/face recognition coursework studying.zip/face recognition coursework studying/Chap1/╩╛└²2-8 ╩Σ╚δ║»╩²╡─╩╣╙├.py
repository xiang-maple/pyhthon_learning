name=input('请输入你的姓名')
print('我的姓名是：'+name)