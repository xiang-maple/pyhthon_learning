num=input('请输入你的幸运数字：')
print('您的幸运数字是：'+num) # 连接成功，说明num是字符串类型
num=int(num) # 使用内置函数int将num转成整数类型
print('您的幸运数字是：',num)