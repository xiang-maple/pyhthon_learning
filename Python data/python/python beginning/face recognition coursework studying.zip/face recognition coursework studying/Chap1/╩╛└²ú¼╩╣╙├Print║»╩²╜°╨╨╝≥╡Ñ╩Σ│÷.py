a=100 # 变量a，值为100
b=50 # 变量b，值为50
print(90)
print(a)
print(a+b)

print("北京欢迎你")
print('北京欢迎你')
print('''北京欢迎你''')