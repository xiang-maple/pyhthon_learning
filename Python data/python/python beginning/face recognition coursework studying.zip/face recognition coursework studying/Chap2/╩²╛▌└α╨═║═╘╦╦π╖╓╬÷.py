# 目标：1. 保留字和标识符
# 2. 变量的定义和使用
# 3.基础数据类型
# 4.掌握数据类型之间的相互转换
# 5.eval()函数的使用
# 6.了解不同的进制数
# 7.python中常见的运算符及优先级
# 1. 什么是保留字， 保留字就是单词（and, del, False, nonlocal, try,as,elif,global.not,Ture.assert.else,if,None,while,break,except,import,or,with,class,fianlly,in,pass,yield,continue,for,is,raise,await,def,from,lambda,return,async）
