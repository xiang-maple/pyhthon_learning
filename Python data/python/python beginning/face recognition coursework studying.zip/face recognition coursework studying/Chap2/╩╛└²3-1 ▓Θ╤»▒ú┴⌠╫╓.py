import keyword
print(keyword.kwlist)
print(len(keyword.kwlist)) # 获取保留字的数量