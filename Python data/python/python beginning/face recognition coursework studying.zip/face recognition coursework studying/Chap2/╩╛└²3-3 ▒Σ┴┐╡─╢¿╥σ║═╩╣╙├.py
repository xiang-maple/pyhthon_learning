shuaige=6 # creat a integer variable, and assign the 8 for it.
my_name='sb' # this is str variable

print('what is the data of shuaige:',type(shuaige))
print(type(my_name))

print(my_name,shuaige)
# Python can change the type of dynamic data, modify directly through the different types of value.
print(type(shuaige))
# python allow the different variables to dedicate one value
no=number=1023 # no and number both dedicate the 1023
print(no,number)
print(id(no)) # id() can check their RAM address is 2777937984528
print(id(number))
