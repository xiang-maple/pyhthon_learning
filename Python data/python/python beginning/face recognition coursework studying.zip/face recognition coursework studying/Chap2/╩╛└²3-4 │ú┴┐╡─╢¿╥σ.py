# Constant definition
pa=313131 # this deines a vraiable\
PA=3131313 # this deines a constant

