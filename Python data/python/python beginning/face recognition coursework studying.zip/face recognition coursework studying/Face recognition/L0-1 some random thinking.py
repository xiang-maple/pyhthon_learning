# 小枫
# @Time : 2024/3/17 8:23
# @Author : 小贤 
# @Version :3.11.4
# @IDE : PyCharm 
# @Project : python

def game(i):  # whatever i = what, the answer is 12
    if i == 1:  # ???
        s = 0
        t = [1, 2, 2, 3, 4]
        for i in t:
            s += i
        return s


print(game(1))
