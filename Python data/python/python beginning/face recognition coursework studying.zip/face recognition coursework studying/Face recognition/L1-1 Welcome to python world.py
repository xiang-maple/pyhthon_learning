# 小枫
# @Time : 2024/3/15 13:39
# @Author : 小贤 
# @Version :3.11.4
# @IDE : PyCharm
# @Project : python studying pro

# When we have download the python and pycharm, we enter the python world, and we say 'Hello World'.
print('hello world')

# if python is language, writing and read is basic element of it.
# for the aspect, we know the reading words, grammer, and writing habits are our direction to learn it.
# But python also has some appliment of math. As the result of it. The words have many categories.
