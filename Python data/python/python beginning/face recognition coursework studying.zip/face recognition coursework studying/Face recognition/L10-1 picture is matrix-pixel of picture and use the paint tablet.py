# 小枫
# @Time : 2024/3/18 21:09
# @Author : 小贤 
# @Version :3.11.4
# @IDE : PyCharm 
# @Project : python

import cv2

img = cv2.imread('xgxym.10.png')

print(img)

