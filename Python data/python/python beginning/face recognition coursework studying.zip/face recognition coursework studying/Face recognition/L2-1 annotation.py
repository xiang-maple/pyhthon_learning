# 小枫
# @Time : 2024/3/15 13:45
# @Author : 小贤 
# @Version :3.11.4
# @IDE : PyCharm
# @Project : python studying pro

# output hello world(specific annotation)
print('hello world')  # simple annotation Single-line comment


# more row annotation!---multiline comment
'''
first annotation
second
third
'''
print('hello Pycharm')

"""
first 
second
third
"""
print('hello China')
