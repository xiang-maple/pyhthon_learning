# 小枫
# @Time : 2024/3/15 13:56
# @Author : 小贤 
# @Version :3.11.4
# @IDE : PyCharm
# @Project : python studying pro

"""
Name rules:
1.	Consist of number, letter, and underline
2.	Can’t make number in the beginning
3.	Can’t use the keyword!
4.	Capital and small should be distinguished strictly.
"""

a = 1000

name = 'Coxi'

my_love = 'maple'

print(a)

print(name)
cate = type(name)
print(f'name is {cate}')

print(my_love)
"""
In the lesson we learn the way name of the variable and the types of it.
There are many types of it: str list set tuple dict int float True False
"""
