# 小枫
# @Time : 2024/3/15 14:21
# @Author : 小贤 
# @Version :3.11.4
# @IDE : PyCharm
# @Project : python studying pro

# <class int">--int!
a = 100
print(type(a))

# <class 'float'>-- class float!
b = 3.23
print(type(b))

c: int = 200  # clearly indicate the type of variables, I think I should get accustomed to the new forms.

# <class 'bool'>---bool!
d = True
f = False
print(type(d))
print(type(f))

g = "abc"
h = "china person"
k = "maple"
print(type(k))
