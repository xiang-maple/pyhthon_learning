# 小枫
# @Time : 2024/3/16 23:07
# @Author : 小贤 
# @Version :3.11.4
# @IDE : PyCharm 
# @Project : python

order = "y"
print('x' or order)  # 结果为 x
print(order or 'x')  # 结果为 order 所以字符串本身就像1 一样 默认是true
print(not "x")  # 结果 为false， 所以 x 默认 true
