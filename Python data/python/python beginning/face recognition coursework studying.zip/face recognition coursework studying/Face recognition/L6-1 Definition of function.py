# 小枫
# @Time : 2024/3/16 16:11
# @Author : 小贤 
# @Version :3.11.4
# @IDE : PyCharm 
# @Project : python

# define a function

def my_abs(a):  # set the function word, we define a absolute function, define the parameter
    if a >= 0:  # set the  condition
        return a  # as the answer of meet the condition
    else:
        return -a  # same


# attention of it that the format between def and other things!!!!!!!!!!

# adopt the function

result = my_abs(-9)  # when there are many break line,we should use the ctrl + alt + l to change the format so clean it
print(result)  # then we pass the parameter using the specific number!

