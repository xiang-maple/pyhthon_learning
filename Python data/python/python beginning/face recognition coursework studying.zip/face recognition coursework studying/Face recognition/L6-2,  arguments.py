# 小枫
# @Time : 2024/3/16 16:30
# @Author : 小贤 
# @Version :3.11.4
# @IDE : PyCharm 
# @Project : python

# 1. Necessary parameter passing
def sum_of_number(start, end):
    """this function is used to compute all the sum of numbers"""
    s = 0
    for i in range(start, end + 1):
        s += i
    return s


print(sum_of_number(1, 100))  # the position is strict.
# 2. Keyword parameter passing
print(sum_of_number(end=100, start=1))  # we don't care the position, but key must be first


# 3. Default parameter passing
def sum_of_number1(start, end, init_value=1):
    """this function is used to compute all the sum of numbers"""
    s = init_value
    for i in range(start, end + 1):
        s += i
    return s


'''if we not change the initial number, we can not adopt it,
 but if we want to change it we can'''
print(sum_of_number1(1, 100, 10))  # we can not use the default value and change it.
print(sum_of_number1(1, 100))  # if we not change the init_value, it will be the default.


# Indefinite long parameter passing
# 1. normal argument
def test1(*number):  # 2
    print(type(number))  # 3
    for i in number:  # 4
        print(i)  # 5


test1(10, 20, 10000)  # for normal parameter this is first step


# keyword argument
def test2(**kws):  # must be such form--**variable
    print(type(kws))  # the print should be retracted in the def
    for k, v in kws.items():
        print(f'argument name is {k},value is {v}')


test2(q=222, w=223, e=224)
