# 小枫
# @Time : 2024/3/16 20:03
# @Author : 小贤 
# @Version :3.11.4
# @IDE : PyCharm 
# @Project : python

"""1.return sentence characters"""


def test1():
    print(1)
    # return  # if we use return, the code behind the return would not be acted.
    print("hello")


result = test1()
print(result)

"""2. return many values"""


def test3(a):
    s = a ** 2
    t = a ** 3
    return [s, t]


# r1, r2 = test2(9)
# result = test2(9)
# print(type(result))
# print(r1, r2)
r1, r2 = test3(9)  # test3(9) is the list
result = test3(9)
print(type(result))
print(result)
print(test3(9))
print(r1, r2)
