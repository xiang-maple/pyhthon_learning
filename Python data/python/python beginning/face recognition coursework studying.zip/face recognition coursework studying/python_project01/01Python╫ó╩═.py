# 马士兵教育
# @Time : 2022/5/25 14:38
# @Author : 肖斌老师
# @Version : 
# @IDE : PyCharm
# @Project : python_project01

# 输出hello world
print('hello world')  # 简单注释，有两个空格


# 多行注释
'''
第一行注释
第二行注释
第三行注释
....
'''
print('hello Python')

"""
第一行注释
第二行注释
第三行注释
....
"""
print('hello 中国')
