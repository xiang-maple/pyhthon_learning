# 马士兵教育
# @Time : 2022/5/25 13:37
# @Author : 肖斌老师
# @Version : 
# @IDE : PyCharm
# @Project : python_project01

print('hello world!')
