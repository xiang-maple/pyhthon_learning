# 马士兵教育
# @Time : 2022/5/25 16:20
# @Author : 肖斌老师
# @Version : 
# @IDE : PyCharm
# @Project : python_project01


"""
标识符命名规则是Python中定义各种名字的时候的统一规范，具体如下：

- 由数字、字母、下划线组成

- 不能数字开头

- 不能使用内置关键字

- 严格区分大小写
"""
a = 1000

name = "肖斌"

my_name = "肖斌"

print(a)

print(my_name)
