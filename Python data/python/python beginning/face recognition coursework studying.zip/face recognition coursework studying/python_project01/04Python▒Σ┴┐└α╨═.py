# 马士兵教育
# @Time : 2022/5/25 17:54
# @Author : 肖斌老师
# @Version : 
# @IDE : PyCharm
# @Project : python_project01


# <class 'int'> --整形
a = 100
print(type(a))

c: int = 200  # 明确声明了变量的类型


# <class 'float'>  -- 浮点型
b = 3.14
print(type(b))

# <class 'bool'> 布尔类型
d = True
f = False
print(type(d))
print(type(f))

# <class 'str'> --字符串
g = 'abc123'
h = '中国人'
k = "马士兵教育"
print(type(k))
