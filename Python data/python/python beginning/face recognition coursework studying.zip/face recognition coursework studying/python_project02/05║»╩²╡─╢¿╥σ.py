# 马士兵教育
# @Time : 2022/7/6 13:41
# @Author : 肖斌老师
# @Version : 
# @IDE : PyCharm
# @Project : python_project02

"""1、定义一个函数"""


def my_abs(a):
    if a >= 0:
        return a
    else:
        return -a


"""2、调用函数"""

result = my_abs(-9)
print(result)
