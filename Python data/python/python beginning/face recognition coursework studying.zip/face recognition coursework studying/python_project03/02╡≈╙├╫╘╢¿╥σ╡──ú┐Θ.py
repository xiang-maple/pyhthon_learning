# 马士兵教育
# @Time : 2022/7/20 14:32
# @Author : 肖斌老师
# @Version : 
# @IDE : PyCharm
# @Project : python_project03

from my_module1 import *

test1(20, 20)
test2(10, 10)
