# 马士兵教育
# @Time : 2022/7/20 14:55
# @Author : 肖斌老师
# @Version : 
# @IDE : PyCharm
# @Project : python_project03

__all__ = ['mod2']
