# 马士兵教育
# @Time : 2022/8/6 20:29
# @Author : 肖斌老师
# @Version : 
# @IDE : PyCharm
# @Project : python_project04

import cv2

img = cv2.imread('cat.jpeg')

print(img)